﻿namespace kars
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            hb = new TextBox();
            label7 = new Label();
            button1 = new Button();
            sa = new TextBox();
            ase = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            groupBox2 = new GroupBox();
            label8 = new Label();
            label9 = new Label();
            label5 = new Label();
            label6 = new Label();
            linkLabel1 = new LinkLabel();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(hb);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(sa);
            groupBox1.Controls.Add(ase);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(63, 49);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(221, 212);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // hb
            // 
            hb.Location = new Point(88, 140);
            hb.Name = "hb";
            hb.Size = new Size(57, 23);
            hb.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(18, 143);
            label7.Name = "label7";
            label7.Size = new Size(52, 15);
            label7.TabIndex = 6;
            label7.Text = "2.Sayınız";
            // 
            // button1
            // 
            button1.Location = new Point(70, 183);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 5;
            button1.Text = "Karşılaştır";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // sa
            // 
            sa.Location = new Point(89, 40);
            sa.Name = "sa";
            sa.Size = new Size(56, 23);
            sa.TabIndex = 4;
            // 
            // ase
            // 
            ase.Location = new Point(88, 89);
            ase.Name = "ase";
            ase.Size = new Size(57, 23);
            ase.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 41);
            label1.Name = "label1";
            label1.Size = new Size(52, 15);
            label1.TabIndex = 1;
            label1.Text = "1.Sayınız";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 92);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 2;
            label2.Text = "3.Sayınız";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 25);
            label3.Name = "label3";
            label3.Size = new Size(72, 15);
            label3.TabIndex = 3;
            label3.Text = "Büyük Sayı=";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(108, 25);
            label4.Name = "label4";
            label4.Size = new Size(25, 15);
            label4.TabIndex = 4;
            label4.Text = "......";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(linkLabel1);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(428, 49);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(196, 173);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Enter += groupBox2_Enter;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(24, 80);
            label8.Name = "label8";
            label8.Size = new Size(62, 15);
            label8.TabIndex = 7;
            label8.Text = "Orta Sayı=";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(111, 80);
            label9.Name = "label9";
            label9.Size = new Size(22, 15);
            label9.TabIndex = 8;
            label9.Text = ".....";
            label9.Click += label9_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(24, 128);
            label5.Name = "label5";
            label5.Size = new Size(72, 15);
            label5.TabIndex = 5;
            label5.Text = "Küçük Sayı=";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(111, 128);
            label6.Name = "label6";
            label6.Size = new Size(22, 15);
            label6.TabIndex = 6;
            label6.Text = ".....";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(24, 155);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(148, 15);
            linkLabel1.TabIndex = 9;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "https://github.com/amz63";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Karşılaştırma Sistemi";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button1;
        private TextBox sa;
        private TextBox ase;
        private GroupBox groupBox2;
        private Label label5;
        private Label label6;
        private TextBox hb;
        private Label label7;
        private Label label8;
        private Label label9;
        private LinkLabel linkLabel1;
    }
}
