using System;

namespace kars
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Nuray Hocama Selamlar
            
            // Say�lar� al�yoruz
            int sayi1 = Convert.ToInt32(sa.Text);
            int sayi2 = Convert.ToInt32(ase.Text);
            int sayi3 = Convert.ToInt32(hb.Text);

            // B�y�k, orta ve k���k say�lar� manuel olarak buluyoruz
            int enBuyuk = sayi1;
            int enKucuk = sayi1;
            int orta = sayi1;

            // En b�y�k say�y� bul
            if (sayi2 > enBuyuk)
                enBuyuk = sayi2;
            if (sayi3 > enBuyuk)
                enBuyuk = sayi3;

            // En k���k say�y� bul
            if (sayi2 < enKucuk)
                enKucuk = sayi2;
            if (sayi3 < enKucuk)
                enKucuk = sayi3;

            // Orta say�y� bul
            if ((sayi1 > enKucuk && sayi1 < enBuyuk))
                orta = sayi1;
            else if ((sayi2 > enKucuk && sayi2 < enBuyuk))
                orta = sayi2;
            else
                orta = sayi3;

            // Sonu�lar� etiketlere yazd�r
            label6.Text = enKucuk.ToString(); // En k���k say�
            label9.Text = orta.ToString();    // Orta say�
            label4.Text = enBuyuk.ToString(); // En b�y�k say�

            // Renk de�i�tirme i�lemi
            if (sayi1 == sayi2 && sayi2 == sayi3)
            {
                this.BackColor = Color.Red; // E�er t�m say�lar e�itse
                label6.Text = "e�ittir";
                label9.Text = "e�ittir";
                label4.Text = "e�ittir";
            }
            else
            {
                this.BackColor = Color.LightGreen; // Say�lar farkl�ysa
            }
        } 



        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.Pink;
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
